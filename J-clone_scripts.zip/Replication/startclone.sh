#!/bin/bash 
# Clone PROD to UAT
# start script
#
# startclone.sh
#	sudo useradd -m -G sudo -s /bin/bash -c 'syncUAT - dump database' syncuser
#
# План
#OK- Стоп Jira (stop_UAT_jira.sh)
#OK- Сохранить дамп таблиц(данные) с базы Jira UAT в дамп файлы(createUAT_tbl_dump.sh)
#OK- Сделать rsync с Jira PROD на Jira UAT (createUAT_data_rsync.sh)
#OK- Выгрузить дамп базы Jira PROD (createPROD_db_dump.sh)
#OK- Подготовка к реиндекс "все делаю на UAT" (reUAT_index_file.sh) 
#OK- пропатчить файлы на Jira UAT (patchUAT_file.sh)
#OK- Удалить\создать(пустую) базу Jira UAT (drop_create_UAT_db_jira_empty.sh)
#OK- Восстановить базу Jira UAT (restore_UAT_db_jira.sh)
#OK- Назначить пользовтеля jira владельцем базы jira (chg_owner_UAT_db_jira.sh)
#OK- Пропатчить базу из сохраненных с базы Jira UAT дампов (patchUAT_tbl_db.sh)
#OK- Запуск Jira и reIndex использует токен "svc-user" (start_UAT_reindex.sh)

source ./jconfig.env

SDATE="$(date +"%d%m%y_%H%M")"
#UATDBHOST="uat-db-01.host.com"
#REMOTEUSER="syncuser"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
LOG_DIR="$BASE_DIR/logs"
logfile="logs/startclone_$SDATE.log"
# LOCAL_LOG передаем переменную в createPROD_db_dump.sh, чтоб писать лог локально а не на удаленном хосте
#LOCAL_LOG="logs/DB_PROD_db_dump_${SDATE}.log"
LOCAL_LOG="logs/RMHOST_log_${SDATE}.log"
CHECKPOINT_DIR="$BASE_DIR/completed"


run_script() {
    local SCRIPT="$1"
    local CHECKPOINT="$CHECKPOINT_DIR/$(basename "$SCRIPT").done"

    # не запускать скрипт если есть файл флаг(completed/*.done)
    if [[ -f "$CHECKPOINT" ]]; then
        echo "   SKIP: $SCRIPT already completed earlier." | tee -a "$logfile"
        return 0
    fi

    echo -e "\n ->Run: $SCRIPT" | tee -a "$logfile"

    (
        set -a
        source ./jconfig.env
        set +a

        bash "$SCRIPT"
    )

    local status=$?

    if [[ $status -ne 0 ]]; then
        echo "ERROR: script '$SCRIPT' failed with exit code $status" | tee -a "$logfile"
        exit 1
    fi

    # Если скрипт успешно выполнен, создать файл флаг успешного выполнения(completed/*.done)
    touch "$CHECKPOINT"

    echo "   DONE: $SCRIPT" | tee -a "$logfile"
}

#fun running a script on a remote host
run_remote_script() {
    local REMOTE_SCRIPT="$1"
    local REMOTE_LOG_NAME="$2"
    local CHECKPOINT="$CHECKPOINT_DIR/$(basename "$REMOTE_SCRIPT").done"

    if [[ -f "$CHECKPOINT" ]]; then
        echo "SKIP: $REMOTE_SCRIPT already completed earlier." | tee -a "$logfile"
        return 0
    fi

    local REMOTE_LOG_PATH="$LOG_DIR/$REMOTE_LOG_NAME"
    echo " ->>>Run: $REMOTE_SCRIPT on $REMOTEUSER@$UATDBHOST, log: $REMOTE_LOG_PATH" | tee -a "$logfile"

(
        set -a
        source ./jconfig.env
        set +a

        ssh "$REMOTEUSER@$UATDBHOST" "
            export UATPGPASSWORD="$UATPGPASSWORD"
            export PRODPGPASSWORD="$PRODPGPASSWORD"

            bash -s" < "$REMOTE_SCRIPT"

    ) 2>&1 | tee -a "$REMOTE_LOG_PATH"

#    ssh "$REMOTEUSER@$UATDBHOST" LOCAL_LOG="$REMOTE_LOG_PATH" 'bash -s' < "$REMOTE_SCRIPT" 2>&1 \
#        | tee -a "$REMOTE_LOG_PATH"

        # получение exit-кода удалённого ssh-команды
    local ssh_status=${PIPESTATUS[0]}
    if [[ $ssh_status -ne 0 ]]; then
        echo "ERROR: remote script $REMOTE_SCRIPT failed with exit code $ssh_status" | tee -a "$logfile"
        exit 1
    fi

    # Создать флаг успешного выполнения
    touch "$CHECKPOINT"
    echo "DONE: $REMOTE_SCRIPT" | tee -a "$logfile"
}

echo "Create DIRs"
mkdir -p {backup,logs,result,scripts,completed}



#--- START ---
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile

# Stop UAT Jira
run_script "scripts/stop_UAT_jira.sh"


# Create a dump of values ​​from UAT tables
run_script "scripts/createUAT_tbl_dump.sh"


# Rsync PROD to UAT
run_script "scripts/createPROD_data_rsync.sh"


# Create a dump of the PROD database and copy it to a file on the UAT database server, run from on the UAT database server
run_remote_script "scripts/createPROD_db_dump.sh" "DB_PROD_Jira_dump_$SDATE.log"

# Prepare index file
run_script "scripts/prepare_UAT_index_file.sh"


# Patching config file UAT
run_script "scripts/patch_UAT_file.sh"


# Drop/create(empty) Jira DB, run from on the UAT database server
run_remote_script "scripts/drop_create_UAT_db_jira_empty.sh" "DB_UAT_Jira_drop_create_$SDATE.log"


# Restore UAT db jira
run_remote_script "scripts/restore_UAT_db_jira.sh" "DB_UAT_Jira_restore_$SDATE.log"


# Change owner UAT db jira
run_remote_script "scripts/chg_owner_UAT_db_jira.sh" "DB_UAT_Jira_owner_$SDATE.log"


# Patching DB table
run_script "scripts/patch_UAT_tbl_db.sh"


#- Запуск Jira (200)
#- Запуск Jira ReIndex 
run_script "scripts/start_UAT_reindex.sh"

#echo "<<<---Finish" | tee -a $logfile
