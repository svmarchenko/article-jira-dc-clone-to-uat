#!/bin/bash
# Prepare data rsync
# rsync data PROD to UAT
#
# createPROD_data_rsync.sh
#


SDATE="$(date +"%d%m%y_%H%M")"
flag="SUCCESS"
testDir='/home/jira/replicate/'
sourceDir_opt='/opt/atlassian/'
sourceDir_var='/var/atlassian/'
BASE_DIR="$(readlink -f "$(dirname "$0")")"
RESULT_DIR="$BASE_DIR/../result"
BACKUP_DIR="$BASE_DIR/../backup/UAT_Jira_$SDATE"
tarfile="$BASE_DIR/../backup/UAT_Jira_config_files_$SDATE.tar.gz"
LOG_DIR="$BASE_DIR/../logs"
rTESTlog="$LOG_DIR/RSYNC_test_$SDATE.log"
rOPTlog="$LOG_DIR/RSYNC_opt_$SDATE.log"
rVARlog="$LOG_DIR/RSYNC_var_$SDATE.log"
logfile="$LOG_DIR/DATA_PROD_rsync_$SDATE.log"
export EXCLUDE="$BASE_DIR/rsync_jira.exclude"

echo "UATJIRAHOST:  $UATJIRAHOST"
echo "PRODJIRAHOST: $PRODJIRAHOST"
#exit 1

#Backup old UAT Jira config files
arr_check_file=(
"/opt/atlassian/jira/atlassian-jira/WEB-INF/classes/crowd.properties"
"/opt/atlassian/jira/atlassian-jira/WEB-INF/classes/seraph-config.xml"
"/opt/atlassian/jira/atlassian-jira/WEB-INF/classes/jira-application.properties"
"/opt/atlassian/jira/atlassian-jira/WEB-INF/classes/jpm.xml" 
"/opt/atlassian/jira/bin/setenv.sh"
"/opt/atlassian/jira/conf/server.xml"
"/var/atlassian/application-data/jira/dbconfig.xml"
"/home/jira/.postgresql/root.crt"
)

#PIPESTATUS[0] = код возврата комманды rsync ( первая cmd - перед "|" ) 
#PIPESTATUS[1] = код возврата комманды tee   ( первая cmd - после "|" )


#fun chk file  
check_file() {
    local label="$1"
    local file="$2"

    if [[ ! -f "$file" ]]; then
        echo "echo -e "\n   RUN replicate directory $PRODJIRAHOST:$testDir to $testDir" |tee -a $logfile 2>&1$label ERR_file $file is NOT created" | tee -a "$logfile"
        flag="WARNING"
        return
    fi

    if [[ -s "$file" ]]; then
        echo "     $label file $file CREATED" | tee -a "$logfile"
    else
        echo "     $label ERR_file $file EMPTY" | tee -a "$logfile"
        flag="WARNING"
    fi
}


#fun rsync_error_status
check_rsync_status() {
    local status="$1"
    local rsync_log="$2"
    local main_log="$3"
	
	local msg=""
    local err=""

    case "$status" in
        0)     msg="INFO: rsync completed successfully (status 0)";;
        23|24) msg="INFO: rsync finished with status $status (vanished/partial files allowed)";;
        10)    err="ERROR: rsync socket I/O error (status 10). Connection issue.";;
        11)    err="ERROR: rsync file I/O error (status 11).";;
        12)    err="ERROR: rsync protocol data stream error (status 12).";;
        255)   err="ERROR: ssh connection error (status 255).";;
        *)     err="ERROR: rsync failed with unexpected status $status!";;
    esac

    # msg (NORMAL)
    if [[ -n "$msg" ]]; then
        echo "          $msg" | tee -a "$main_log"
        return 0
    fi

    # err (ERROR)
    echo "          $err" | tee -a "$main_log"
    echo "          Check log: $rsync_log" | tee -a "$main_log"
    exit 1
}


#fun rsync
run_rsync() {
    local remote_host="$1"
    local remote_dir="$2"
    local exclude_file="$3"
    local rsync_log="$4"
    local main_log="$5"

    local local_dir="$remote_dir"

    echo -e "     - $remote_host:$remote_dir to $local_dir" | tee -a "$main_log"
    echo "          rsync log: $rsync_log" | tee -a "$main_log"
    echo "          start time $(date +%H:%M:%S) $(date +%Y-%m-%d)" | tee -a "$main_log"

    rsync -razve "ssh -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null" \
        --exclude-from="$exclude_file" \
        --delete \
        --ignore-errors \
        "${remote_host}:${remote_dir}" "${local_dir}" \
        | tee -a "$rsync_log" 2>&1

    local status=${PIPESTATUS[0]}

    # Call "rsync_error_status" function 
	# Ignore the following errors "0|23|24"
    check_rsync_status "$status" "$rsync_log" "$main_log"

    echo "          end time   $(date +%H:%M:%S) $(date +%Y-%m-%d)" | tee -a "$main_log"
#    echo "       directory replicated  $local_dir" | tee -a "$main_log"
}


#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a $logfile
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile

#---BACKUP---
echo -e "   Preparation(backup):\n     - Backup old UAT Jira config files to $BACKUP_DIR" | tee -a $logfile 2>&1
for file in "${arr_check_file[@]}"; do
    if [[ -f "$file" ]]; then
        # создаём структуру каталогов внутри BACKUP_DIR
        dest_dir="$BACKUP_DIR/$(dirname "$file")"
        mkdir -p "$dest_dir"

        cp -p "$file" "$dest_dir"/
        echo "         Copied:  $file" | tee -a $logfile 2>&1
    else
        echo "         WARNING: File not found: $file" | tee -a $logfile 2>&1
		flag="WARNING"
    fi
done


# бекап старых файлов конфигурпации Jira UAT
echo "     - Archive backup_UAT_Jira_config_files" | tee -a $logfile
cd $BACKUP_DIR
tar -czf "$tarfile" . | tee -a $logfile

check_file "    Archive" "$tarfile"


#--- RSYNC---
echo -e "\n   RUN directory replication(rsync):\n     EXCLUDE:\n$(cat $EXCLUDE)" | tee -a $logfile 2>&1

#opt
run_rsync "$PRODJIRAHOST" "$sourceDir_opt" "$EXCLUDE" "$rOPTlog" "$logfile"

#var
run_rsync "$PRODJIRAHOST" "$sourceDir_var" "$EXCLUDE" "$rVARlog" "$logfile"

#echo -e "     INFO: rsync finished with NORMAL ststus\n          0 -  Successful\n          23 - Partial transfer\n          24 - Partial transfer due to vanished source files" | tee -a $logfile 2>&1 
echo -e "\n   END directory replication(rsync)" | tee -a $logfile 2>&1


echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
exit 0

