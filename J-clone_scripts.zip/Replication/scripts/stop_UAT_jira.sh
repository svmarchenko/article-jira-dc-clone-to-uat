#!/bin/bash 
# Stop UAT Jira
# UAT stop proccess jira.service 
#
# stop_UAT_jira.sh
#


SDATE="$(date +"%d%m%y_%H%M")"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/stop_UAT_jira_$SDATE.log"


#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a $logfile
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile

SERVICE="jira.service"
ATTEMPTS=10
SLEEP_TIME=60

echo "Stopping Jira service..." | tee -a $logfile

for ((i=1; i<=ATTEMPTS; i++)); do
    echo "Attempt $i: systemctl stop $SERVICE" | tee -a $logfile
    systemctl stop "$SERVICE"

    # Check if any processes remain(Java Jira)
    if ! pgrep -f "java.*jira" > /dev/null; then
        echo "Jira stopped successfully." | tee -a $logfile
		echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
        exit 0
    fi

    echo "Jira is still running. Waiting ${SLEEP_TIME}s before retry..." | tee -a $logfile
    sleep $SLEEP_TIME
done

echo "Active processes:" | tee -a $logfile
pgrep -fl "java.*jira"

echo "ERROR: Jira failed to stop after ${ATTEMPTS} attempts." | tee -a $logfile
exit 1

