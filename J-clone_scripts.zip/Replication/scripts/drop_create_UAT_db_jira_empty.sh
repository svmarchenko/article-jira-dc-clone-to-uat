#!/bin/bash
# Drop UAT DB
# running from $UATDBHOST, drop create UAT Jira database
#
# drop_create_UAT_db_jira_empty.sh
#

#echo "UATPGPASSWORD=[$UATPGPASSWORD]"
#echo "length=${#UATPGPASSWORD}"
#env | grep PGPASSWORD
SDATE="$(date +"%d%m%y_%H%M")"
PGPASSWORD="$UATPGPASSWORD"
UATDBPORT="6432"
UATDBNAME="jira"
UATDBUSER="postgres"
flag="SUCCESS"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/DB_UAT_Jira_drop_create.sh_$SDATE.log"

#PIPESTATUS[0] = код возврата комманды psql ( первая cmd - перед "|" )
#PIPESTATUS[1] = код возврата комманды tee  ( первая cmd - после "|" )

#echo -e "\nTEST database" | tee -a "$LOCAL_LOG"
#sudo -u postgres psql -v ON_ERROR_STOP=1 -c "SELECT 1;" \
#    | tee -a "$LOCAL_LOG"

#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a "$LOCAL_LOG"
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a "$LOCAL_LOG"

#--RUN drop UAT jira database
# DROP DB Jira

echo -e "\nRUN drop UAT jira database" | tee -a "$LOCAL_LOG"
sudo -u postgres psql -v ON_ERROR_STOP=1 -c "DROP DATABASE $UATDBNAME;" \
    | tee -a "$LOCAL_LOG"

psql_status=${PIPESTATUS[0]}
if [ $psql_status -ne 0 ]; then
    echo "ERROR: Failed to DROP database $UATDBNAME" | tee -a "$LOCAL_LOG"
    exit 1
fi
echo "   Database $UATDBNAME DROPPED successfully." | tee -a "$LOCAL_LOG"


# CREATE DB Jira
echo -e "\nRUN create(empty) UAT jira database" | tee -a "$LOCAL_LOG"
sudo -u postgres psql -v ON_ERROR_STOP=1 -c "CREATE DATABASE $UATDBNAME;" \
    | tee -a "$LOCAL_LOG"

psql_status=${PIPESTATUS[0]}
if [ $psql_status -ne 0 ]; then
    echo "ERROR: Failed to CREATE database $UATDBNAME" | tee -a "$LOCAL_LOG"
    exit 1
fi

echo "   Database $UATDBNAME CREATED successfully." | tee -a "$LOCAL_LOG"



echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a "$LOCAL_LOG"
exit 0
