#!/bin/bash 
# Patching DB
# patching database from SQL files
#
# patch_UAT_tbl_db.sh
#


export PGPASSWORD="$UATPGPASSWORD"
SDATE="$(date +"%d%m%y_%H%M")"

flag="SUCCESS"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
RESULT_DIR="$BASE_DIR/../result"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/DB_UAT_tbl_patch_$SDATE.log"


#fun chk file  
check_file() {
    local label="$1"
    local file="$2"

    if [[ ! -f "$file" ]]; then
        echo "   $label ERR_file $file is NOT created" | tee -a "$logfile"
        flag="ERROR"
        return
    fi

    if [[ -s "$file" ]]; then
        echo "   $label file $file CREATED" | tee -a "$logfile"
    else
        echo "   $label ERR_file $file EMPTY" | tee -a "$logfile"
        flag="ERROR"
    fi
}



#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a $logfile
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile


##---SQL0
echo -e "\n  SQL0 "| tee -a $logfile
# файл DROP созданных ранее скриптом временных таблиц "tmp_property*_export*"
cat << EOF > $RESULT_DIR/SQLR1_DROP_tmp_table_export_delete.sql
DROP TABLE IF EXISTS tmp_propertyentry_export;
DROP TABLE IF EXISTS tmp_propertystring_export;
DROP TABLE IF EXISTS tmp_propertyentry_export_delete;
EOF
check_file "" "$RESULT_DIR/SQLR1_DROP_tmp_table_export_delete.sql"


# DROP временных таблиц "tmp_property*_export*"
echo -e "    DROP temporary tables: tmp_property*_export"
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $RESULT_DIR/SQLR1_DROP_tmp_table_export_delete.sql 1> >(tee -a $logfile) 2>/dev/null


#--RUN database patching
echo -e "\nRUN database patching from SQL files" | tee -a $logfile

##---SQLRTS1
echo -e "\n  SQLRTS1" | tee -a $logfile
echo "    UPDATE_cwd_directory_attribute.sql (Crowd URL)" | tee -a $logfile
psql -U jira -h $UATDBHOST -p 6432 jira < $RESULT_DIR/UAT_tbl_dump/UPDATE_cwd_directory_attribute.sql \
  | awk '{print "    psql: UPDATE table cwd_directory_attribute (Crowd URL)", $0}' | tee -a $logfile


##---SQLRTS2
echo -e "\n  SQLRTS2" | tee -a $logfile
echo "    UPDATE_propertystring.sql (Color)" | tee -a $logfile
psql -U jira -h $UATDBHOST -p 6432 jira < $RESULT_DIR/UAT_tbl_dump/UPDATE_propertystring.sql \
  | awk '{print "    psql: UPDATE table propertystring (Color)", $0}' | tee -a $logfile

######
##--SQLRTS2_1
echo -e "\n  SQLRTS2_1" | tee -a $logfile
echo "    UPDATE_propertystring.sql (bBaseurl)" | tee -a $logfile

#######
##---SQLRTS3
echo -e "\n  SQLRTS3" | tee -a $logfile
echo "    RENEW table AO_4AEACD_WEBHOOK_DAO" | tee -a $logfile
psql -U jira -h $UATDBHOST -p 6432 -d jira -c 'DROP TABLE IF EXISTS "AO_4AEACD_WEBHOOK_DAO";' \
  | awk '{print "    psql: DROP table  AO_4AEACD_WEBHOOK_DAO"}' | tee -a $logfile


pg_restore -v -U jira -h $UATDBHOST -p 6432 -d jira "$RESULT_DIR/UAT_tbl_dump/AO_4AEACD_tbl.dump" 2>&1 \
  | awk '{print "   ", $0}' \
  | tee -a "$logfile"


##---SQLRTS4
echo -e "\n  SQLRTS4" | tee -a $logfile
echo "    RENEW table AO_88DE6A_CONNECTION" | tee -a $logfile
psql -U jira -h $UATDBHOST -p 6432 -d jira -c 'DROP TABLE IF EXISTS "AO_88DE6A_CONNECTION";' \
  | awk '{print "    psql: DROP table  AO_88DE6A_CONNECTION"}' | tee -a $logfile

pg_restore -U jira -h $UATDBHOST -p 6432 -d jira $RESULT_DIR/UAT_tbl_dump/AO_88DE6A_tbl.dump \
  | awk '{print "     ", $0}' \
  | tee -a "$logfile"


##---SQLRTS5
echo -e "\n  SQLRTS5" | tee -a $logfile
# UPDATE данных в таблицах "propertyentry" и "propertystring"
# файл CREATE временную таблицу "tmp_propertyentry_export_delete" (в ней строки с id которые нужно удалить)
cat << EOF > $RESULT_DIR/SQLR1_CREATE_tmp_propertyentry_export_for_DELETE.sql
CREATE TABLE tmp_propertyentry_export_delete AS
SELECT *
FROM propertyentry AS pe
WHERE (pe.entity_name = 'jira.properties'
       AND pe.property_key LIKE 'applinks.admin%'
       AND pe.propertytype = 5)
   OR pe.property_key = 'your.integration.properties'
;
EOF
check_file "" "$RESULT_DIR/SQLR1_CREATE_tmp_propertyentry_export_for_DELETE.sql" | tee -a $logfile
# файл SELECT получаю список id для запроса из временной таблицы "tmp_propertyentry_export_delete"
#cat << EOF > SQLR1_SELECT_tmp_propertyentry_export_DELETE.sql
#SELECT string_agg(id::text, ',') FROM "tmp_propertyentry_export_delete"
#;
#EOF

# CREATE временную таблицу "tmp_propertyentry_export_delete" (SQLR1_CREATE_tmp_propertyentry_export_for_DELETE.sql)
echo "    CREATE temporary tables: tmp_propertyentry_export_delete" | tee -a $logfile
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $RESULT_DIR/SQLR1_CREATE_tmp_propertyentry_export_for_DELETE.sql \
  | awk '{print "    psql: CREATE table tmp_propertyentry_export_delete", $0}' | tee -a $logfile
# Сохраняю id из таблицы "propertyentry" для чистки по ним в таблице "propertystring" (SQLR1_SELECT_propertyentry_export_id_DELETE.out)
#psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f SQLR1_SELECT_tmp_propertyentry_export_DELETE.sql > SQLR1_SELECT_propertyentry_export_id_DELETE.out | awk '{print "    psql: Table tmp_propertyentry_export ", $0}'  | tee -a $logfile

# Удалить из таблицы "propertyentry" все строки которые есть в "tmp_propertyentry_export_delete"
echo "    DELETE from table: propertyentry" | tee -a "$logfile"
psql -U jira -h "$UATDBHOST" -p 6432 jira -c \
"DELETE FROM propertyentry WHERE id IN (SELECT id FROM tmp_propertyentry_export_delete);" \
  | awk '{print "    psql: DELETE from table propertyentry: " $0}' \
  | tee -a "$logfile"

  
#Удалить из таблицы "propertystring" строки с id которые есть в "tmp_propertyentry_export_delete"
echo "    DELETE from table: propertystring" | tee -a "$logfile"
psql -U jira -h "$UATDBHOST" -p 6432 jira -c \
"DELETE FROM propertystring WHERE id IN (SELECT id FROM tmp_propertyentry_export_delete);" \
  | awk '{print "    psql: DELETE from table propertystring: " $0}' \
  | tee -a "$logfile"


# CREATE в propertyentry во временную таблицу tmp_propertyentry_export
#CREATE TABLE tmp_propertyentry_export (LIKE propertyentry INCLUDING ALL);   если затру -- создать структуру таблицы из propertyentry
echo "    CREATE table: tmp_propertyentry_export" | tee -a "$logfile"
psql -v ON_ERROR_STOP=1 \
  -U jira -h $UATDBHOST -p 6432 -d jira \
  -f "$RESULT_DIR/UAT_tbl_dump/INSERT_propertyentry_export_dump.sql" \
  | awk '{print "    psql: CREATE table tmp_propertyentry_export", $0}' | tee -a $logfile

  
# INSERT данных из временной таблицы tmp_propertyentry_export в propertyentry(уже очищенная от ПРОД строк)
echo "    INSERT data to table: propertyentry" | tee -a "$logfile"
psql -U jira -h $UATDBHOST -p 6432 jira -c "
INSERT INTO propertyentry
SELECT *
FROM tmp_propertyentry_export;
" \
  | awk '{print "    psql: INSERT INTO table propertyentry", $0}' | tee -a $logfile

# CREATE в propertystring данных в соответсвий с id во временную таблицу tmp_propertystring_export
echo -e"\n    CREATE table: tmp_propertyentry_export" | tee -a "$logfile"
psql -v ON_ERROR_STOP=1 \
  -U jira -h $UATDBHOST -p 6432 -d jira \
  -f "$RESULT_DIR/UAT_tbl_dump/INSERT_propertystring_export_dump.sql" \
  | awk '{print "    psql: CREATE table tmp_propertystring_export", $0}' | tee -a $logfile
  
  
# INSERT данных из временной таблицы tmp_propertystring_export в propertystring(уже очищенная от ПРОД строк)
echo "    INSERT data to table: propertystring" | tee -a "$logfile"
psql -U jira -h $UATDBHOST -p 6432 jira -c "
INSERT INTO propertystring
SELECT *
FROM tmp_propertystring_export;
" \
  | awk '{print "    psql: INSERT INTO table propertystring", $0}' | tee -a $logfile


# UPDATE Crowd DB password в таблице cwd_directory_attribute - Jira10 добавить пароль от базы crowd
echo "    UPDATE data in table: cwd_directory_attribute" | tee -a "$logfile"
psql -U jira -h "$UATDBHOST" -p 6432 jira \
  -v ON_ERROR_STOP=1 \
  -c "UPDATE cwd_directory_attribute
      SET attribute_value = 'jira'
      WHERE attribute_name = 'application.password'
      AND directory_id = 10000;" \
  2>&1 | awk '{print "    psql: UPDATE table cwd_directory_attribute", $0}' \
  | tee -a "$logfile"


# DELETE mail handler passwords - Jira10 удалить mail handlers c UAT, "createissue" и "createissue2"
echo "    DELETE data in table: mailserver" | tee -a "$logfile"
psql -U jira -h "$UATDBHOST" -p 6432 jira \
  -v ON_ERROR_STOP=1 \
  -c "DELETE FROM mailserver
      WHERE mailusername IN ('createissue', 'createissue2');" \
  2>&1 | awk '{print "    psql: DELETE in table mailserver", $0}' \
  | tee -a "$logfile"


##---SQL0
#Удалить таблицы "tmp_property*_export*"
echo -e "\n  SQL0 "| tee -a $logfile
# файл DROP созданных ранее скриптом временных таблиц "tmp_property*_export*"
echo -e "    DROP temporary tables: tmp_property*_export"
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $RESULT_DIR/SQLR1_DROP_tmp_table_export_delete.sql 1> >(tee -a $logfile) 2>/dev/null



 
echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
exit 0
