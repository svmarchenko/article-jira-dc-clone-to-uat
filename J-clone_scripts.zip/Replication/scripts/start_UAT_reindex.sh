#!/bin/bash 
# Start reindex
# running and start reindex UAT Jira
# после реиндекса отдает 200
#
#start_UAT_reindex.sh
#



SDATE="$(date +"%d%m%y_%H%M")"
SERVICE="jira.service"
ATTEMPTS=20
# SLEEP_TIME в секундах
SLEEP_TIME=60
JIRASTAT='http://localhost:8080/jira/rest/api/2/serverInfo'
#JIRAINDEXTOKEN user svc-user 
JIRATOKEN="your-token"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/APPS_UAT_Jira_reindex_$SDATE.log"

#Cleaning up unnecessary data before starting
arr_dir_del=(
"/var/atlassian/application-data/jira/logs/support/*"
"/var/atlassian/application-data/jira/log/*"
"/var/atlassian/application-data/jira/import/*"
"/var/atlassian/application-data/jira/export/*"
"/var/atlassian/application-data/jira/tmp/*"
"/var/atlassian/application-data/jira/caches/*"
"/var/atlassian/application-data/jira/scriptrunner/*"
)


#fun wait_jira_ready
wait_jira_ready() {
    local URL="$1"
    local TOKEN="$2"
    local ATTEMPTS="$3"
    local SLEEP_TIME="$4"
    local LOGFILE="$5"
    local attempt_i=1
    local http_code

    while [ "$attempt_i" -le "$ATTEMPTS" ]; do
        http_code=$(curl \
            -H "Authorization: Bearer $TOKEN" \
            -s -o /dev/null -i -w "%{http_code}" \
            "$URL"
        )
        if [ "$http_code" = "200" ]; then
            echo "   Jira is ready (HTTP $http_code) on attempt $attempt_i" | tee -a "$LOGFILE"
            return 0
        fi
        if [ "$attempt_i" -eq "$ATTEMPTS" ]; then
            echo "ERROR: Jira did NOT ready after $ATTEMPTS attempts" | tee -a "$LOGFILE"
            return 1
        fi
        echo "   Attempt $attempt_i/$ATTEMPTS: Jira not ready (HTTP $http_code), retry in ${SLEEP_TIME}s..." \
            | tee -a "$LOGFILE"
        sleep "$SLEEP_TIME"
        attempt_i=$((attempt_i + 1))
    done
}


#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a "$LOCAL_LOG"
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a "$LOCAL_LOG"

# чистим старое данные из папок
echo "Cleaning dir "| tee -a $logfile
#rm -rf ${arr_dir_del[@]} | tee -a $logfile


#--START Service JIRA---
echo "Starting Jira service..." | tee -a $logfile
started=false
for ((i=1; i<=ATTEMPTS; i++)); do
    echo "   Attempt $i: systemctl start $SERVICE" | tee -a "$logfile"
    systemctl start "$SERVICE"

    # Check if Jira process is running
    if pgrep -f "java.*jira" > /dev/null; then
        echo "   Jira service started successfully." | tee -a "$logfile"
        started=true
        break
    fi

    echo "   Jira not running yet. Waiting ${SLEEP_TIME}s before retry..." | tee -a "$logfile"
    sleep "$SLEEP_TIME"
done

if [ "$started" != true ]; then
    echo "ERROR: Jira NOT started after $ATTEMPTS attempts." | tee -a "$logfile"
    exit 1
fi


#--WAITING start JIRA (http://localhost:8080/jira/rest/api/2/serverInfo = 200)
echo "Waiting for Jira to be ready for ReIndex: $JIRASTAT" | tee -a "$logfile"
wait_jira_ready "$JIRASTAT" "$JIRATOKEN" "$ATTEMPTS" "$SLEEP_TIME" "$logfile" || exit 1


#--RUN reindex UAT jira
echo "Start ReIndex Jira "| tee -a $logfile
# Успешно идет реиндекс проверка в Jira log пишет "endpoint пишет recovered index from <filename>"
curl -H "Authorization: Bearer $JIRATOKEN" \
  -X POST http://localhost:8080/jira/rest/scriptrunner/latest/custom/doReindex | tee -a "$logfile"


#--WAITING start JIRA 
echo -e "\nWaiting for Jira to be ready: $JIRASTAT" | tee -a "$logfile"
#sleep 60
wait_jira_ready "$JIRASTAT" "$JIRATOKEN" "$ATTEMPTS" "$SLEEP_TIME" "$logfile" || exit 1


echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
exit 0
