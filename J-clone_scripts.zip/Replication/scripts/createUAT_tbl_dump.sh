#!/bin/bash 
# Prepare SQL reqest
# save dump UAT tables
#
# createUAT_tbl_dump.sh
#


export PGPASSWORD="$UATPGPASSWORD"
#UATDBHOST="$UATDBHOSTIP"
SDATE="$(date +"%d%m%y_%H%M")"
dtSQLR0="SQLR1_DROP_tmp_table_export.sql"
ctSQLR1="SQLR1_CREATE_tmp_propertyentry_export.sql"
dtSQLR1="SQLR1_DROP_tmp_propertyentry_export.sql"
stSQLR1="SQLR1_SELECT_tmp_propertyentry_export.sql"
ctSQLR2="SQLR2_CREATE_tmp_propertystring_export.sql"
dtSQLR2="SQLR2_DROP_tmp_propertystring_export.sql"

#CWD_ATTR="https://uat.host.com/crowd"
#JIRA_COL="#4ba308"
#JIRA_BASEURL="https://uat.host.com/jira"
flag="SUCCESS"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
RESULT_DIR="$BASE_DIR/../result"
BACKUP_DIR="$BASE_DIR/../backup"
LOG_DIR="$BASE_DIR/../logs"
DUMP_TPATH="$RESULT_DIR/UAT_tbl_dump"
tarfile="$BACKUP_DIR/UAT_tbl_dump_$SDATE.tar.gz"
logfile="$LOG_DIR/DB_UAT_tbl_dump_$SDATE.log"

echo "PGPASSWORD:   $PGPASSWORD"
echo "UATDBHOST:    $UATDBHOST"
echo "CWD_ATTRT:    $CWD_ATTR"
echo "JIRA_COL:     $JIRA_COL"
echo "JIRA_BASEURL: $JIRA_BASEURL"



echo "PGPASSWORD exists in env:"
env | grep PGPASSWORD || echo "NOT EXPORTED"

#export PGPASSWORD

#exit 1
arr_file_del=(
$dtSQLR0
$ctSQLR1
$dtSQLR1
$stSQLR1
$ctSQLR2
$dtSQLR2
)

arr_check_file=(
"INSERT_propertyentry_export_dump.sql" 
"SQLR1_SELECT_tmp_propertyentry_export_id.out" 
"INSERT_propertystring_export_dump.sql"
"AO_4AEACD_tbl.dump" 
"AO_88DE6A_tbl.dump"
"UPDATE_cwd_directory_attribute.sql"
"UPDATE_propertystring.sql"
)


#fun chk file  
check_file() {
    local label="$1"
    local file="$2"

    if [[ ! -f "$file" ]]; then
        echo "   $label ERR_file $file is NOT created" | tee -a "$logfile"
        flag="ERROR"
        return
    fi

    if [[ -s "$file" ]]; then
        echo "   $label file $file CREATED" | tee -a "$logfile"
    else
        echo "   $label ERR_file $file EMPTY" | tee -a "$logfile"
        flag="ERROR"
    fi
}


#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a $logfile
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
#cd /pgdata/postgresql/backup/jiraDB/clone
cd $BASE_DIR
mkdir $DUMP_TPATH
echo -e"  BASE_DIR: $BASE_DIR\n   PWD:     $(pwd)"

##---SQL0
echo "  SQL0 "| tee -a $logfile
# файл DROP созданных ранее скриптом временных таблиц "tmp_property*_export"
cat << EOF > $dtSQLR0
DROP TABLE IF EXISTS tmp_propertyentry_export;
DROP TABLE IF EXISTS tmp_propertystring_export;
EOF
check_file "" "$dtSQLR0"
#check_file "$dtSQLR0" 

# DROP временных таблиц "tmp_property*_export"
echo "11111     DROP temporary tables: tmp_property*_export"
#psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $dtSQLR0
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $dtSQLR0 1> >(tee -a $logfile) 2>/dev/null


##---SQLR1
echo "  SQL1 "| tee -a $logfile
# файл CREATE временную таблицу "tmp_propertyentry_export"
cat << EOF > $ctSQLR1
CREATE TABLE tmp_propertyentry_export AS
SELECT *
FROM propertyentry AS pe
WHERE (pe.entity_name = 'jira.properties'
       AND pe.property_key LIKE 'applinks.admin%'
       AND pe.propertytype = 5)
   OR pe.property_key = 'your.integration.properties'
;
EOF
check_file "" "$ctSQLR1"

# файл DROP временную таблицу "tmp_propertyentry_export"
cat << EOF > $dtSQLR1
DROP TABLE tmp_propertyentry_export
;
EOF
check_file "" "$dtSQLR1"

# файл SELECT получаю список id для запроса в SQLR2
cat << EOF > $stSQLR1
SELECT string_agg(id::text, ',') FROM "tmp_propertyentry_export"
;
EOF
check_file "" "$stSQLR1"


# CREATE временную таблицу "tmp_propertyentry_export" SQLR1_CREATE_tmp_propertyentry_export.sql
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $ctSQLR1 | awk '{print "    psql: Table tmp_propertyentry_export ", $0}' | tee -a $logfile

# DUMP временной таблицы "tmp_propertyentry_export"
pg_dump -U jira -h $UATDBHOST -p 6432 -d jira -t tmp_propertyentry_export \
  --inserts \
  > INSERT_propertyentry_export_dump.sql | awk '{print "    pg_dump: Table tmp_propertyentry_export ", $0}' | tee -a $logfile
check_file "" "${arr_check_file[0]}" 


# SELECT id из временной таблицы SQLR1_SELECT_tmp_propertyentry_export.sql
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $stSQLR1 > SQLR1_SELECT_tmp_propertyentry_export_id.out | awk '{print "    psql: Table tmp_propertyentry_export ", $0}'  | tee -a $logfile
check_file "" "${arr_check_file[1]}"


##---SQL2
echo "  SQL2 "| tee -a $logfile
# файл CREATE временную таблицу "tmp_propertystring_export"
cat << EOF > $ctSQLR2
CREATE TABLE tmp_propertystring_export AS
SELECT *
FROM propertystring
WHERE id IN (
$(cat SQLR1_SELECT_tmp_propertyentry_export_id.out)
);
EOF
check_file "" "$ctSQLR2"

# файл DROP временную таблицу "tmp_propertystring_export"
cat << EOF > $dtSQLR2
DROP TABLE tmp_propertystring_export
;
EOF
check_file "" "$dtSQLR2"

# CREATE временную таблицу "tmp_propertystring_export" SQLR2_CREATE_tmp_propertystring_export.sql
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $ctSQLR2 | awk '{print "    psql: Table tmp_propertystring_export ", $0}' | tee -a $logfile


# DUMP временной таблицы "tmp_propertystring_export"
pg_dump -U jira -h $UATDBHOST -p 6432 -d jira -t tmp_propertystring_export \
  --inserts \
  > INSERT_propertystring_export_dump.sql | awk '{print "   pg_dump: Table  tmp_propertystring_export ", $0}' | tee -a $logfile
#check_file "INSERT_propertystring_export_dump.sql"
check_file "" "${arr_check_file[2]}"



##---SQL3
echo "  SQL3 "| tee -a $logfile
#SQLR3, дамп таблицы в файле AO_4AEACD_tbl.dump
pg_dump -U jira -h $UATDBHOST -p 6432 -d jira -t '"AO_4AEACD_WEBHOOK_DAO"' \
  -Fc > AO_4AEACD_tbl.dump | awk '{print "    pg_dump: Table  AO_4AEACD_WEBHOOK_DAO ", $0}' | tee -a $logfile
#  pg_restore -U jira -h $UATDBHOST -p 6432 -d jira AO_4AEACD_tbl.dump
check_file "" "${arr_check_file[3]}"


##---SQL4
echo "  SQL4 "| tee -a $logfile
#SQLR4, дамп таблицы в файле AO_88DE6A_tbl.dump
pg_dump -U jira -h $UATDBHOST -p 6432 -d jira -t '"AO_88DE6A_CONNECTION"' \
  -Fc > AO_88DE6A_tbl.dump | awk '{print "    pg_dump: Table  AO_88DE6A_CONNECTION ", $0}' | tee -a $logfile
#  pg_restore -U jira -h $UATDBHOST -p 6432 -d jira AO_88DE6A_tbl.dump
check_file "" "${arr_check_file[4]}" 

##---SQLR5
echo "  SQL5 "| tee -a $logfile
# создаю файл с апдейтом  таблицы "cwd_directory_attribute"
cat << EOF > UPDATE_cwd_directory_attribute.sql
UPDATE cwd_directory_attribute
SET attribute_value = '$CWD_ATTR'
WHERE directory_id = 10000
  AND attribute_name = 'crowd.server.url'
;
EOF
check_file "" "${arr_check_file[5]}"

# создаю файл с апдейтом  таблицы "propertystring"
cat << EOF > UPDATE_propertystring.sql
UPDATE propertystring
SET propertyvalue = '$JIRA_COL'
WHERE id = (
    SELECT id 
    FROM propertyentry 
    WHERE property_key = 'jira.lf.top.bgcolour'
	)
;

UPDATE propertystring
SET propertyvalue = '$JIRA_BASEURL'
	WHERE id = (SELECT id 
	FROM propertyentry 
	WHERE property_key = 'jira.baseurl'
	)
;
EOF

check_file "" "${arr_check_file[6]}"



##---SQL0
echo "  SQL0 "| tee -a $logfile
# DROP временных таблиц "tmp_property*_export"
#echo "     DROP temporary tables: tmp_property*_export"
psql -U jira -h $UATDBHOST -p 6432 jira -t -A -f $dtSQLR0 | awk '{print "    psql: Table tmp_property*_export ", $0}' | tee -a $logfile


echo -e "\n  RESULT:" | tee -a "$logfile"
check_file "   Backup table(insert_dump):" "${arr_check_file[0]}"
check_file "   Backup table(insert_dump):" "${arr_check_file[2]}"
check_file "   Backup table(related__id):" "${arr_check_file[1]}" #
check_file "   Backup table(full___dump):" "${arr_check_file[3]}"
check_file "   Backup table(full___dump):" "${arr_check_file[4]}"
check_file "   Backup table(update_dump):" "${arr_check_file[5]}"
check_file "   Backup table(update_dump):" "${arr_check_file[6]}"

# Проверка на ошибки в RESULT, есть ошибка exit 1
#echo "falg: $flag"
if [[ "$flag" == "ERROR" ]]; then
    echo "ERROR detected — stopping script $(readlink -f "$0")" | tee -a $logfile
    exit 1
fi

#бекап дампов таблиц
#echo "         Backup_UAT_tbl_dump: $tarfile" | tee -a $logfile
tar -czf "$tarfile" -C "$BASE_DIR" *.sql *.out *.dump | tee -a $logfile
#tar -czf $tarfile *.sql *.out *.log
check_file "   Backup UAT_tbl_dump:      " "$tarfile"


#Чистка дириктории
rm ${arr_file_del[@]} | tee -a $logfile

#mv *.{out,sql,tar.gz} $DUMP_TPATH
mv *.{out,sql,dump} $DUMP_TPATH | tee -a $logfile
echo -e "\n      Backup table dump file MOVED to $DUMP_TPATH" | tee -a $logfile
 
echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
exit 0
