#!/bin/bash 
# Prepare config file
# patching config file UAT
#
# patch_UAT_file.sh
#



SDATE="$(date +"%d%m%y_%H%M")"
#change PROD to UAT value
PROD_JIRAHOST="your_PROD_JIRAHOST"
PROD_PGPASSWORD="{ATL_SECURED}"
#PROD_DBHOST="PROD_DBHOST1:6432,PROD_DBHOST2:6432,PROD_DBHOST3"
PROD_DBHOST="PROD_DBHOST1:6432"
UAT_JIRAHOST="your_UAT_JIRAHOST"
UAT_PGPASSWORD="your_PostgresPASSWORD"
UAT_DBHOST="UAT_DB_HOST""
UAT_JIRANAME="uat"
# индивидуално для каждого хоста
PROD_JIRAMEM='_MEMORY="30g"'
UAT_JIRAMEM='_MEMORY="18g"'
#
flag="SUCCESS"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
RESULT_DIR="$BASE_DIR/../result"
BACKUP_DIR="$BASE_DIR/../backup/UAT_Jira_$SDATE"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/DATA_UAT_patch_$SDATE.log"
tarfile="$RESULT_DIR/patchedfile.tar.gz"


#Backup old UAT Jira config files
arr_check_file=(
"/opt/atlassian/jira/atlassian-jira/WEB-INF/classes/crowd.properties"
"/opt/atlassian/jira/bin/setenv.sh"
"/opt/atlassian/jira/conf/server.xml"
"/var/atlassian/application-data/jira/dbconfig.xml"
)

#fun chk file  
check_file() {
    local label="$1"
    local file="$2"

    if [[ ! -f "$file" ]]; then
        echo "   $label ERR_file $file is NOT present" | tee -a "$logfile"
        flag="ERROR"
        return
    fi

    if [[ -s "$file" ]]; then
        echo "   $label file $file is present" | tee -a "$logfile"
    else
        echo "   $label ERR_file $file EMPTY" | tee -a "$logfile"
        flag="ERROR"
    fi
}


replace_uat_jira_host=$(printf '%s\n' "$UAT_JIRAHOST" | sed 's/[\/&]/\\&/g')
replace_uat_db_host=$(printf '%s\n' "$UAT_DBHOST" | sed 's/[\/&]/\\&/g')
search__prod_db_pwd=$(printf '%s\n' "$PROD_PGPASSWORD" | sed 's/[\/&]/\\&/g')
replace_uat_db_pwd=$(printf '%s\n' "$UAT_PGPASSWORD" | sed 's/[\/&]/\\&/g')
replace_uat_name=$(printf '%s\n' "$UAT_JIRANAME" | sed 's/[\/&]/\\&/g')
search__prod_jira_mem=$(printf '%s\n' "$PROD_JIRAMEM" | sed 's/[\/&]/\\&/g')
replace_uat_jira_mem=$(printf '%s\n' "$UAT_JIRAMEM" | sed 's/[\/&]/\\&/g')



#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a $logfile
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
echo -e "\n   RUN patching Jira config files" | tee -a $logfile
        
sed -i "s/your/$replace_uat_name/g" /opt/atlassian/jira/atlassian-jira/WEB-INF/classes/crowd.properties | tee -a "$logfile"
check_file "" "${arr_check_file[0]}"
sed -i "s/$PROD_JIRAHOST/$replace_uat_jira_host/g" /opt/atlassian/jira/bin/setenv.sh | tee -a "$logfile"
sed -i "s/$search__prod_jira_mem/$replace_uat_jira_mem/g" /opt/atlassian/jira/bin/setenv.sh | tee -a "$logfile"
check_file "" "${arr_check_file[1]}"
sed -i "s/your/$replace_uat_name/g" /opt/atlassian/jira/conf/server.xml | tee -a "$logfile"
check_file "" "${arr_check_file[2]}"
sed -i "s/$PROD_DBHOST/$replace_uat_db_host/g" /var/atlassian/application-data/jira/dbconfig.xml | tee -a "$logfile"
sed -i "s/$search__prod_db_pwd/$replace_uat_db_pwd/g" /var/atlassian/application-data/jira/dbconfig.xml | tee -a "$logfile"
check_file "" "${arr_check_file[3]}"

# Проверка на ошибки в RESULT, есть ошибка exit 1
#echo "falg: $flag"
if [[ "$flag" == "ERROR" ]]; then
    echo "ERROR detected — stopping script $(readlink -f "$0")" | tee -a $logfile
    exit 1
fi


# Удаление файлов и директорий особенность Jira10, связано с шифрованием пароля
echo "   Deleting the secured/keys directories and the secrets-config.yaml file" | tee -a $logfile
#/var/atlassian/application-data/jira/secured/
#/var/atlassian/application-data/jira/keys/
#/var/atlassian/application-data/jira/secrets-config.yaml
rm -rf /var/atlassian/application-data/jira/secured/
rm -rf /var/atlassian/application-data/jira/keys/
rm /var/atlassian/application-data/jira/secrets-config.yaml

# Смена владельца
echo "   Chown Jira directory" | tee -a $logfile
chown jira:jira /opt/atlassian/ -R
#chown jira:jira /var/atlassian/ -R

#бекап пропатченых файлов Jira
echo -e "\n   Archive patched_file: $tarfile" | tee -a $logfile
tar -czPf "$tarfile" "${arr_check_file[@]}" 2>>"$logfile"


echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
exit 0
