#!/bin/bash 
# Change OWNER UAT DB
# running from $UATDBHOST, change OWNER UAT Jira database
#
# chg_owner_UAT_db_jira.sh
#


export PGPASSWORD="$UATPGPASSWORD"
SDATE="$(date +"%d%m%y_%H%M")"

UATDBNAME="jira"
UATDBUSER="postgres"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/DB_UAT_Jira_owner_$SDATE.log"


#fun chk file  
check_file() {
    local label="$1"
    local file="$2"

    if [[ ! -f "$file" ]]; then
        echo "   $label ERR_file $file is NOT created" | tee -a "$logfile"
        flag="ERROR"
        return
    fi

    if [[ -s "$file" ]]; then
        echo "   $label file $file CREATED" | tee -a "$logfile"
    else
        echo "   $label ERR_file $file EMPTY" | tee -a "$logfile"
        flag="ERROR"
    fi
}



#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a "$LOCAL_LOG"
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a "$LOCAL_LOG"

#--RUN change OWNER UAT jira database
# файл смена OWNERа Jira в UAT DB
cat << 'EOF' > $BASE_DIR/SQL_CHG_OWNER_JIRA_UAT_DB.sql
ALTER DATABASE jira OWNER TO jira;
ALTER SCHEMA public OWNER TO jira;

DO $$
DECLARE
    r record;
BEGIN
    FOR r IN
        SELECT tablename
        FROM pg_tables
        WHERE schemaname = 'public'
    LOOP
        EXECUTE format(
            'ALTER TABLE public.%I OWNER TO jira',
            r.tablename
        );
    END LOOP;
END $$;
EOF
check_file "" "$BASE_DIR/SQL_CHG_OWNER_JIRA_UAT_DB.sql"

echo -e "\nRun Change OWNER on Jira UAT database" | tee -a "$LOCAL_LOG"
sudo -u $UATDBUSER psql -U $UATDBUSER -d $UATDBNAME -v ON_ERROR_STOP=1 \
     -f "$BASE_DIR/SQL_CHG_OWNER_JIRA_UAT_DB.sql" 2>&1 \
| awk '{print "    psql: change OWNER UAT Jira database", $0}' | tee -a "$LOCAL_LOG"

psql_status=${PIPESTATUS[0]}
if [ $psql_status -ne 0 ]; then
    echo "ERROR: Failed OWNER NOT changed" | tee -a "$LOCAL_LOG"
    exit 1
fi
echo "   Database $UATDBNAME OWNER changed successfully." | tee -a "$LOCAL_LOG"

echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a "$LOCAL_LOG"
exit 0
