#!/bin/bash 
# Prepare Index file
# moving index file
#
# prepare_UAT_index_file.sh
#

#source jconfig.env
#echo "Host: $UATJIRAHOST = UAT_JIRAHOST" 

SDATE="$(date +"%d%m%y_%H%M")"
flag="SUCCESS"
INDEX_DIR="/var/atlassian/application-data/jira/caches/indexesV2/snapshots"
INDEX_CP_DIR="/var/atlassian/PRODindex"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/DATA_UAT_index_$SDATE.log"

#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a $logfile
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
echo -e "\n   RUN prepare index file" | tee -a $logfile

mkdir -p $INDEX_CP_DIR

rm $INDEX_CP_DIR/* | tee -a $logfile

echo "   list of all index files:" | tee -a $logfile
ls -la  | tee -a $logfile

latest_file=$(ls -t $INDEX_DIR/*.tar.sz  | head -n 1)
echo "   latest created index file:\n     $latest_file" | tee -a $logfile

cp -a "$latest_file" $INDEX_CP_DIR | tee -a $logfile
echo "   index file copied to $INDEX_CP_DIR" | tee -a $logfile

rm $INDEX_DIR/* | tee -a $logfile
echo "   index directory cleaned" | tee -a $logfile


echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a $logfile
exit 0

