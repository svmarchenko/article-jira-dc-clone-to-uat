#!/bin/bash 
# Restore UAT DB
# running from $UATDBHOST, restore UAT Jira database
#
# restore_UAT_db_jira.sh
#


export PGPASSWORD="$UATPGPASSWORD"
SDATE="$(date +"%d%m%y_%H%M")"

UATDBHOST="UAT_DB_HOST"
UATDBPORT="6432"
UATDBNAME="jira"
UATDBUSER="postgres"
DUMPFILE="jiraPROD.dump"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/DB_UAT_Jira_pg_restore_$SDATE.log"

#PIPESTATUS[0] = код возврата комманды psql ( первая cmd - перед "|" ) 
#PIPESTATUS[1] = код возврата комманды tee  ( первая cmd - после "|" )

#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a "$LOCAL_LOG"
echo "-->START $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a "$LOCAL_LOG"

#--RUN restore UAT jira database
# RESTORE DB Jira
echo -e "\nRun Jira UAT database restore from $DUMPFILE" | tee -a "$LOCAL_LOG"
sudo -u $UATDBUSER pg_restore --no-owner --no-acl -v -d $UATDBNAME /pgdata/postgresql/backup/jiraDB/$DUMPFILE \
    | tee -a "$LOCAL_LOG"

psql_status=${PIPESTATUS[0]}
if [ $psql_status -ne 0 ]; then
    echo "ERROR: Failed to RESTORE database $UATDBNAME" | tee -a "$LOCAL_LOG"
    exit 1
fi
echo "   Database $UATDBNAME RESTORED successfully." | tee -a "$LOCAL_LOG"


 
echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") $(readlink -f "$0")" | tee -a "$LOCAL_LOG"
exit 0
