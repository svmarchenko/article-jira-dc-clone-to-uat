#!/bin/bash
# create dump PROD JIRA DB 
# running from $UATDBHOST, save Jira DB dump on $UATDBHOST
#
# createPROD_db_dump.sh
#

#echo "PRODPGPASSWORD=[$PRODPGPASSWORD]"
#echo "length=${#PRODPGPASSWORD}"
#env | grep PGPASSWORD

#в этом скрипте PROD PGPASSWORD
export PGPASSWORD="$PRODPGPASSWORD"
SDATE="$(date +"%d%m%y_%H%M")"
PRODDBHOST="PROD_DB_HOST"
BASE_DIR="$(readlink -f "$(dirname "$0")")"
DUMP_TPATH="$BASE_DIR/../result/UAT_tbl_dump"
LOG_DIR="$BASE_DIR/../logs"
logfile="$LOG_DIR/DB_PROD_db_dump_$SDATE.log"

#ssh user@remote-host 'bash -s arg1 arg2' < script.sh

#exit 1
#--- START ---
echo "-->RUNs on the host: $(hostname)" | tee -a "$LOCAL_LOG"
echo -e "\n<--START completed $(date +"%d%m%y_%H:%M") \t$(hostname): $(readlink -f "$0")/createPROD_db_dump.sh" | tee -a "$LOCAL_LOG"
pg_dump -v -U jira -h $PRODDBHOST -p 6432 -Fc -f /pgdata/postgresql/backup/jiraDB/jiraPROD.dump jira | tee -a "$LOCAL_LOG"


echo -e "\n<--SUCCESSFUL completed $(date +"%d%m%y_%H:%M") \t$(hostname): $(readlink -f "$0")/createPROD_db_dump.sh" | tee -a "$LOCAL_LOG"
exit 0
